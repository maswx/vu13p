
# AD9695-EVAL HDL reference design

Here are some pointers to help you:
  * [Board Product Page](https://www.analog.com/eval-ad9695.html)
  * Parts : [14-Bit, 1300 MSPS/625 MSPS, JESD204B, Dual Analog-to-Digital Converter](https://www.analog.com/ad9695.html)
  * Project Doc: https://wiki.analog.com/resources/eval/user-guides/ad9695_fmc
  * HDL Doc: https://wiki.analog.com/resources/eval/user-guides/ad9695_fmc
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers-all

