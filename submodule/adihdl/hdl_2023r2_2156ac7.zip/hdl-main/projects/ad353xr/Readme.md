# AD353XR HDL Driver

Here are some pointers to help you:
  * [Board Product Page] To Be Released
  * Parts : [ AD353XR Family of Low Power, Buffered Voltage Output, SPI DAC ] To Be Released
  * Project Doc: https://wiki.analog.com/resources/eval/user-guides/ad353xr
  * HDL Doc: https://wiki.analog.com/resources/eval/user-guides/ad353xr
  * Linux Drivers: To be added after PR and Upstream