# AD77681-EVB HDL Project

Here are some pointers to help you:
  * [Board Product Page](https://www.analog.com/eval-ad7768-1)
  * Parts : [AD7768-1, DC to 204 kHz, Dynamic Signal Analysis, Precision 24-Bit ADC with Power Scaling](https://www.analog.com/ad7768-1)
  * Parts : [ADAQ7768-1, 24-Bit Single Channel Precision μModule Data Acquisition System](https://www.analog.com/adaq7768-1)
  * Project Doc: https://wiki.analog.com/resources/eval/user-guides/ad7768-1
  * HDL Doc: https://wiki.analog.com/resources/eval/user-guides/ad7768-1
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers/iio-adc/ad7768-1
