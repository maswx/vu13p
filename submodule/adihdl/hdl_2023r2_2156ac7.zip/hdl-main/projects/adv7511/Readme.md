# ADV7511 HDL Project

Here are some pointers to help you:
  * Part : [225 MHz, High Performance HDMI® Transmitter with ARC](https://www.analog.com/adv7511)
  * Project Doc: https://wiki.analog.com/resources/fpga/xilinx/kc705/adv7511
  * HDL Doc: https://wiki.analog.com/resources/fpga/xilinx/kc705/adv7511
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers/drm/adv7511
