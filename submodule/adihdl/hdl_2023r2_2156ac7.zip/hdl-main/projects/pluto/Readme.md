# PLUTO HDL Project

Here are some pointers to help you:
  * [Board Product Page](https://www.analog.com/adalm-pluto)
  * [Board Product Page](https://www.analog.com/cn0566)
  * Parts : [RF Agile Transceiver](https://www.analog.com/ad9363)
  * Project Doc: https://wiki.analog.com/university/tools/pluto	
  * Project Doc: https://wiki.analog.com/resources/eval/user-guides/circuits-from-the-lab/cn0566
  * HDL Doc: https://wiki.analog.com/resources/eval/user-guides/ad-fmcomms2-ebz/reference_hdl
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers/iio-transceiver/ad9361
