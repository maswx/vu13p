# ADALM2000 HDL Project

Here are some pointers to help you:
  * [Board Product Page](https://www.analog.com/adalm2000)
  * Parts : [AD9963 12-Bit, Low Power, Broadband MxFE](https://www.analog.com/AD9963)
  * Project Doc: https://wiki.analog.com/m2k
  * HDL Doc: https://wiki.analog.com/resources/fpga/docs/hdl/m2k
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers-all
