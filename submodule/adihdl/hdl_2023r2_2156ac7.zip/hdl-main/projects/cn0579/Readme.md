# CN0579 HDL Project

Here are some pointers to help you:
  * [Board Product Page](https://www.analog.com/en/products/cn0579.html)
  * Parts : [Multichannel IEPE DAQ for CbM](https://www.analog.com/en/products/cn0579.html)
            [8-Channel, 24-Bit, Simultaneous Sampling ADC](https://www.analog.com/ad7768)
  * Project Doc: https://wiki.analog.com/resources/eval/user-guides/cn0579
  * HDL Doc: https://wiki.analog.com/resources/eval/user-guides/cn0579
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers/iio-adc/ad7768