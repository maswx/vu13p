# JUPITER_SDR HDL Project

Here are some pointers to help you:
  * [Board Product Page](https://www.analog.com/jupiter_sdr)
  * Parts : [RF Agile Transceiver](https://www.analog.com/adrv9002)
  * Project Doc: https://wiki.analog.com/university/tools/jupiter_sdr
  * HDL Doc: https://wiki.analog.com/resources/eval/user-guides/jupiter_sdr/reference_hdl
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers/iio-transceiver/adrv9002
