# AD485x HDL Project

Here are some pointers to help you:
  * [Board Product Page](https://www.analog.com/eval-ad4858)
  * Parts : [AD485x(1-8)](https://www.analog.com/ad4858)
  * Project Doc: https://wiki.analog.com/resources/eval/user-guides/ad4858_fmcz
  * HDL Doc: https://wiki.analog.com/resources/eval/user-guides/ad4858_fmcz/ad4858_fmcz_hdl
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers/iio-adc/axi-adc-hdl
