# AD-DAC-FMC-EBZ reference HDL design for ZCU102

|||
| ------ | ------ |
| Wiki  | https://wiki.analog.com/resources/eval/user-guides/ad-dac-fmc-ebz |
| FMC Location | FMC HPC0 Slot |
| Configuration file | ../common/config.tcl |
