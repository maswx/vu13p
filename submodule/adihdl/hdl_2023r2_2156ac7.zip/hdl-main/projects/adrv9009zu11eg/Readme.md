# ADRV9009-ZU11EG HDL Project

Here are some pointers to help you:
  * [Board Product Page](https://www.analog.com/adrv9009-zu11eg)
  * Parts : [Integrated Dual RF Tx, Rx, and Observation Rx](https://www.analog.com/adrv9009)
  * Project Doc: https://wiki.analog.com/resources/eval/user-guides/adrv9009-zu11eg
  * HDL Doc: https://wiki.analog.com/resources/eval/user-guides/adrv9009-zu11eg/hdl
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers/iio-transceiver/adrv9009
